﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    //Variables
    public GameObject enemyPrefab;
    public GameObject powerUpPrefab;

    private float spawnRange = 9;

    public int enemyCount;
    public int waveNumber;

    // Start is called before the first frame update
    void Start()
    {
        SpawnEnemyWave(waveNumber);
    }

    private void SpawnEnemyWave(int enemiesToSpawn)
    {
        for (int i = 0; i < enemiesToSpawn; i++)
        {
            //Spawn the enemy in the scene
            Instantiate(enemyPrefab, GeneratesSpawnPosition(), enemyPrefab.transform.rotation);
        }
    }

    // Update is called once per frame
    void Update()
    {
        //find the enemy object by its script
        enemyCount = FindObjectsOfType<Enemy>().Length;

        //Manage the Spawn of more waves if all enemies die and power ups   
        if (enemyCount == 0)
        {
            Instantiate(powerUpPrefab, GeneratesSpawnPosition(), powerUpPrefab.transform.rotation);
            waveNumber++;
            SpawnEnemyWave(waveNumber);

        }

    }

    private Vector3 GeneratesSpawnPosition()
    {
        //Generate random values between -9 and 9
        float spawnPosX = Random.Range(-spawnRange, spawnRange);
        float spawnPosZ = Random.Range(-spawnRange, spawnRange);

        Vector3 randomPos = new Vector3(spawnPosX, 0, spawnPosZ);

        return randomPos;


    }



}





