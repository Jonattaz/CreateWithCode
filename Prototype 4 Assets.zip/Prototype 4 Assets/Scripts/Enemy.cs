﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{   //Variables
    public float speed;

    private Rigidbody EnemyRb;

    private GameObject player;


    // Start is called before the first frame update
    void Start()
    {
        EnemyRb = GetComponent<Rigidbody>();
        player = GameObject.Find("Player");

    }

    // Update is called once per frame
    void Update()
    {
        //Calculates the direction that the enemy moves towards
        Vector3 lookDirection = (player.transform.position - transform.position).normalized;

        //Makes the enemy follow the player
        EnemyRb.AddForce(lookDirection * speed);

        //Destroy the enemies if they fall
        if (transform.position.y < -10)
        {
            Destroy(gameObject);
        }


    }
}








