﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    //Variables
    private Rigidbody playerRb;

    public float speed = 5.0f;
    private float powerUpStrength = 15.0f;

    public bool hasPowerUp = false;

    public GameObject powerUpIndicator;
    private GameObject focalPoint;

    private Vector3 offset = new Vector3(0, -0.5f, 0);

    // Start is called before the first frame update
    void Start()
    {
        playerRb = GetComponent<Rigidbody>();

        //Find an object that is in the scene
        focalPoint = GameObject.Find("Focal Point");
    }

    // Update is called once per frame
    void Update()
    {
        //Controls the player and camera
        float forwardInput = Input.GetAxis("Vertical");
        playerRb.AddForce(focalPoint.transform.forward * speed * forwardInput);
        powerUpIndicator.transform.position = transform.position + offset;

    }

    private void OnTriggerEnter(Collider other)
    {
        //Activate the power up
        if (other.CompareTag("PowerUp"))
        {
            hasPowerUp = true;
            powerUpIndicator.gameObject.SetActive(true);
            Destroy(other.gameObject);
            StartCoroutine(PowerUpCountDownRoutine());
        }

    }

    //Responsable for the time that the power up will work
    IEnumerator PowerUpCountDownRoutine()
    {
        yield return new WaitForSeconds(7);
        powerUpIndicator.gameObject.SetActive(false);
        hasPowerUp = false;
    }



    private void OnCollisionEnter(Collision collision)
    {
        //Verifies if the player collided with an enemy, when using a power up to cause an effect
        if (collision.gameObject.CompareTag("Enemy") && hasPowerUp)
        {
            //variables
            Rigidbody enemyRigibody = collision.gameObject.GetComponent<Rigidbody>();
            Vector3 awayfromPlayer = (collision.gameObject.transform.position - transform.position);

            Debug.Log("Player collided with " + collision.gameObject + " with power up set to " + hasPowerUp);
            //Makes the enemy fly away from the player
            enemyRigibody.AddForce(awayfromPlayer * powerUpStrength, ForceMode.Impulse);

        }

    }


}
