﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    //Variables
    public float jumpForce = 10;
    public float gravityModifier;

    public bool isGround = true;
    public bool gameOver = false;

    public ParticleSystem explosionParticle;
    public ParticleSystem dirtParticle;

    public AudioClip jumpSound;
    public AudioClip crashSound;
    private AudioSource playerAudio;

    private Rigidbody playerRb;


    private Animator PlayerAnim;



    // Start is called before the first frame update
    void Start()
    {
        //Get the rigidbody component and adds gravity to the player
        playerRb = GetComponent<Rigidbody>();
        Physics.gravity *= gravityModifier;
        PlayerAnim = GetComponent<Animator>();
        playerAudio = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        //When pressed space the player jump, according with the conditions
        if (Input.GetKeyDown(KeyCode.Space) && isGround && !gameOver)
        {
            playerRb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
            isGround = false;
            PlayerAnim.SetTrigger("Jump_trig");
            dirtParticle.Stop();
            playerAudio.PlayOneShot(jumpSound, 1.0f);

        }
    }

    // Is Ground serves to prevent double jumping
    private void OnCollisionEnter(Collision collision)
    {



        //Checks if there is a collision and then if the collided object has the tag Ground      
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGround = true;
            dirtParticle.Play();
        }

        // Takes care of the collision related to obstacles and gameover
        else if (collision.gameObject.CompareTag("Obstacle"))
        {
            gameOver = true;
            Debug.Log("Game Over");
            PlayerAnim.SetBool("Death_b", true);
            PlayerAnim.SetInteger("DeathType_int", 1);
            dirtParticle.Stop();
            explosionParticle.Play();
            playerAudio.PlayOneShot(crashSound, 1.0f);
        }

    }


}












