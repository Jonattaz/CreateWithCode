﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    //Variables
    private float startDelay = 2;
    private float repeatRate = 2;

    public GameObject obstaclePrefab;

    private Vector3 spawnPos = new Vector3(30, 0, 0);

    private PlayerController playerControllerScript;


    // Start is called before the first frame update
    void Start()
    {
        playerControllerScript = GameObject.Find("Player").GetComponent<PlayerController>();
        //Invoke the obstacle according with the start delay and repeat rate
        InvokeRepeating("SpawnObstacle", startDelay, repeatRate);

    }

    // Update is called once per frame
    void Update()
    {

    }

    //Instantiate the obstacle in the scene
    void SpawnObstacle()
    {
        //Check if gameover has been activated so there is no more Spawn of objects
        if (playerControllerScript.gameOver == false)
        {

            Instantiate(obstaclePrefab, spawnPos, obstaclePrefab.transform.rotation);

        }


    }


}

