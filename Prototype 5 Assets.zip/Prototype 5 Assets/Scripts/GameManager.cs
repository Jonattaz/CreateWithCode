﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    //Variables
    public List<GameObject> targets;

    private float spawnRate = 1.0f;

    public int score;

    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI gameoverText;

    public Button restartButton;

    public GameObject titleScreen;

    public bool isGameActive = true;

    //this coroutine spawns the targets in the scene
    IEnumerator SpawnTarget()
    {
        while (isGameActive)
        {
            yield return new WaitForSeconds(spawnRate);
            int index = Random.Range(0, targets.Count);
            Instantiate(targets[index]);
        }
    }

    //Update the player's score
    public void UpdateScore(int scoreToAdd)
    {
        score += scoreToAdd;
        scoreText.text = "Score: " + score;
    }

    //Game Over method
    public void GameOver()
    {
        restartButton.gameObject.SetActive(true);
        gameoverText.gameObject.SetActive(true);
        isGameActive = false;
    }

    //Restart Method
    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    //Start the game and controls the dificulty
    public void StartGame(int difficulty)
    {
        isGameActive = true;
        StartCoroutine(SpawnTarget());
        score = 0;
        spawnRate /= difficulty;
        UpdateScore(0);

        titleScreen.gameObject.SetActive(false);
    }
}










