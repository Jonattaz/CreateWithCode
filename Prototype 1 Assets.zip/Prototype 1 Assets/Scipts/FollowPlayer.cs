﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowPlayer : MonoBehaviour
{
    //Variables
    public GameObject Player;
    [SerializeField] private Vector3 offset = new Vector3(0, 10, -9);

    // Start is used for something that needs to work when the game starts
    // Awake makes some objects do something only when you need it in-game
    void Awake()
    {
    }

    //is useful to calculate the camera position
    void LateUpdate()
    {
        //Makes the main camera follow the player
        transform.position = Player.transform.position + offset;
    }
}
