﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    //Variables
    //SerializeField let you see the private variable in the inspector
    // Const means constant, you will never be able to change the speed value
    [SerializeField] private const float speed = 50.0f;
    // Protected is a mixture of private and public, you can use it in other scripts or classes that inherit from the main class
    [SerializeField] protected float turnSpeed = 100.0f;
    private float horizontalInput;
    private float verticalInput;
    private float xRange = 94;
    private float zRangeMin = -10.0f;
    private float zRangeMax = 189.0f;
    //readonly works when in you first instantiate an object you can set the variable when the object is created, but you can never change it ever again
    private readonly float test = 10;
    // Static works if you want to use a global variable anywhere in your code all the time
    private static float test1 = 120;

    // FixedUpdate happens before the update and is used in physical movements
    void FixedUpdate()
    {
        //Move the vehicle forward
        //transform.Translate(0, 0, 2);

        //Player Movement
        horizontalInput = Input.GetAxis("Horizontal");
        verticalInput = Input.GetAxis("Vertical");

        //Moves the car forward based on vertical  input
        transform.Translate(Vector3.forward * Time.deltaTime * speed * verticalInput);

        // OLD CODE HORIZONTAL ---> transform.Translate(Vector3.right * Time.deltaTime * turnSpeed * horizontalInput);

        //Rotates the car based on horizontal input
        transform.Rotate(Vector3.up, turnSpeed * horizontalInput * Time.deltaTime);

        //Calls the method in the updated 
        Walls();


    }

    //Invisible walls method
    private void Walls()
    {

        //Limit the player movement in the X axis
        if (transform.position.x < -xRange)
        {
            transform.position = new Vector3(-xRange, transform.position.y, transform.position.z);
        }
        else if (transform.position.x > xRange)
        {
            transform.position = new Vector3(xRange, transform.position.y, transform.position.z);
        }


        //Limit the player movement in the Z axis
        if (transform.position.z < -zRangeMin)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, -zRangeMin);
        }
        else if (transform.position.z > zRangeMax)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, zRangeMax);
        }
    }
}
