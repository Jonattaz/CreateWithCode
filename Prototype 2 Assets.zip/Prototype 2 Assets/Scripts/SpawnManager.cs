﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{   
    //Variables
    public GameObject[] animalPrefabs;
    private float spawnRangeX = 10;
    private float spawnPosZ = 20;
    private float startDelay = 1;
    private float spawnInterval = 0.5f;


    // Start is called before the first frame update
    void Start()
    {
        //Calls the method with start time and a interval between the others spawns
        InvokeRepeating("SpawnRandomAnimals", startDelay, spawnInterval);
    }


    //Method used do create the random spawn of the animals
    void SpawnRandomAnimals()
    {
        //Randomize the animals who will appear and the position
        int animalIndex = Random.Range(0, animalPrefabs.Length);
        Vector3 spawnPos = new Vector3(Random.Range(-spawnRangeX, spawnRangeX), 0, spawnPosZ);

        Instantiate(animalPrefabs[animalIndex], spawnPos, animalPrefabs[animalIndex].transform.rotation);
    }


}
