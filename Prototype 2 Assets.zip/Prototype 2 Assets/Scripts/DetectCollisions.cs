﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DetectCollisions : MonoBehaviour
{
    //Detects collision with trigger colliders
    private void OnTriggerEnter(Collider other)
    {
       //Destroys the object who has the script
        Destroy(gameObject);

        //Destroys the other object
        Destroy(other.gameObject);
    }

}
