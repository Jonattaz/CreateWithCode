﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveForward : MonoBehaviour
{   //Variable
    public float speed = 40;

    void Update()
    {   
        //Makes the animals and the projectile move forward
        transform.Translate(Vector3.forward * Time.deltaTime * speed);
    }
}
